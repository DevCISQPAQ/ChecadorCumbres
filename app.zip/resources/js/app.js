import './bootstrap';
import Alpine from 'alpinejs';
import './qrscan.js';
import './timenow.js';
import './addasistencia.js';
import './loaderform.js';
window.Alpine = Alpine;

Alpine.start();