<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="shortcut icon" type="image/svg" href="<?php echo e(asset('/img/sello-cumbres-en-blanco-01.png')); ?>">
    <link rel="shortcut icon" sizes="192x192" href="<?php echo e(asset('/img/sello-cumbres-en-blanco-01.png')); ?>">
</head>

<body x-data="{
        sidebarOpen: false,
        toggleSidebar() {
            this.sidebarOpen = !this.sidebarOpen;
        }
    }"
    class="bg-gray-100 h-screen flex relative overflow-x-hidden transition-all duration-300">

    
    <aside :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full'"
        class="fixed inset-y-0 left-0 w-64 h-screen flex flex-col bg-white shadow-md z-40 transform transition-transform duration-300 ease-in-out md:static md:translate-x-0">
        <?php if (isset($component)) { $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin-sidebar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $attributes = $__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__attributesOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2)): ?>
<?php $component = $__componentOriginal6fc2d165f80d597f34aa0f8014c366d2; ?>
<?php unset($__componentOriginal6fc2d165f80d597f34aa0f8014c366d2); ?>
<?php endif; ?>
    </aside>

    
    <div class="flex-1 flex flex-col w-full">

        
        <header class="bg-white shadow px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div class="flex items-center gap-4">
                
                <button @click="toggleSidebar" class="md:hidden text-gray-700">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>

                <h1 class="text-lg sm:text-xl md:text-2xl lg:text-3xl font-semibold text-gray-800">
                    Control de Asistencias
                </h1>
            </div>

            <div class="flex items-center gap-4 self-end sm:self-auto">
                <span class="text-gray-700 font-medium">👤 <?php echo e(Auth::user()->name); ?></span>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
                    <?php echo csrf_field(); ?>
                </form>

                <button onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
                    class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded">
                    Cerrar sesión
                </button>
            </div>
        </header>


        
        <main class="p-6 flex-1 overflow-y-auto">
            <?php if(session('success') || session('error')): ?>
            <div class="<?php echo e(session('success') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?> p-3 rounded mb-4">
                <?php echo e(session('success') ?? session('error')); ?>

            </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    <!-- Loader general -->
    <div id="loader" style="display:none; position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(255,255,255,0.7); z-index:9999; align-items:center;justify-content:center;">
        <div class="w-16 h-16 border-4 border-blue-500 border-dashed rounded-full animate-spin"></div>
    </div>

</body>

</html><?php /**PATH C:\Desarrollos-Alex\Dev-Cumbres\ChecadorCumbres\resources\views/layouts/admin.blade.php ENDPATH**/ ?>