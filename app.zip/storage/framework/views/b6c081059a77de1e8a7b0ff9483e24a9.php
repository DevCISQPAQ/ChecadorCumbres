<?php
$empleadoUnico = null;
$todosMismoEmpleado = true;

if(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Empleado) {
    // Si es colección de empleados
    $primerEmpleado = $asistencias[0] ?? null;
    foreach ($asistencias as $empleado) {
        if (is_null($empleadoUnico)) {
            $empleadoUnico = $empleado;
        } elseif ($empleadoUnico->id !== $empleado->id) {
            $todosMismoEmpleado = false;
            break;
        }
    }
} elseif(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Asistencia) {
    // Si es colección de asistencias
    $primerEmpleado = $asistencias[0]->empleado ?? null;
    foreach ($asistencias as $asistencia) {
        if (is_null($empleadoUnico)) {
            $empleadoUnico = $asistencia->empleado;
        } elseif ($empleadoUnico->id !== $asistencia->empleado->id) {
            $todosMismoEmpleado = false;
            break;
        }
    }
} else {
    $primerEmpleado = null;
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(public_path('css/pdf.css')); ?>" type="text/css">
    <title>Reporte de Asistencias</title>
</head>

<body>
    <table class="w-full">
        <tr>
            <td class="w-half">
                <img src="<?php echo e(public_path('img/escudo-gris.svg')); ?>" alt="Logo" style="width: .5rem;">
            </td>
            <td class="w-half">
                <h2>Cumbres International School</h2>
            </td>
        </tr>
    </table>

    <div class="margin-top">
        <table class="w-full">
            <tr>
                <td class="w-half">
                    <div>
                        <h4>Reporte de Asistencias</h4>
                    </div>
                    <?php if($todosMismoEmpleado && $empleadoUnico): ?>
                        <p>De: <?php echo e($empleadoUnico->nombres); ?> <?php echo e($empleadoUnico->apellido_paterno); ?> <?php echo e($empleadoUnico->apellido_materno); ?></p>
                    <?php endif; ?>
                </td>
                <td class="w-half" style="text-align: right;">
                    Fecha: <?php echo e(now()->format('d/m/Y')); ?>

                </td>
            </tr>
        </table>
    </div>

    <div class="margin-top">
        <table class="products">
            <thead>
                <tr>
                    <th>N. Empleado</th>
                    <th>Nombre</th>
                    <th>Departamento</th>
                    <th>Hora de entrada</th>
                    <th>Hora de salida</th>
                    <th>Retardo</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $totalRetardos = 0;
                ?>

                <?php if(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Empleado): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="items">
                            <td><?php echo e($empleado->id); ?></td>
                            <td><?php echo e($empleado->nombres . ' ' . $empleado->apellido_paterno . ' ' . $empleado->apellido_materno); ?></td>
                            <td><?php echo e($empleado->departamento); ?></td>
                            <td style="color: red;">Sin registro</td>
                            <td style="color: red;">Sin registro</td>
                            <td style="color: red;">Sin registro</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">No se encontraron registros.</td></tr>
                    <?php endif; ?>
                <?php elseif(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Asistencia): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $empleado = $asistencia->empleado;
                            if ($asistencia->retardo) {
                                $totalRetardos++;
                            }
                        ?>
                        <tr class="items">
                            <td><?php echo e($asistencia->empleado_id ?? 0); ?></td>
                            <td><?php echo e($empleado ? $empleado->nombres . ' ' . $empleado->apellido_paterno . ' ' . $empleado->apellido_materno : 'N/A'); ?></td>
                            <td><?php echo e($empleado->departamento ?? 'N/A'); ?></td>
                            <td <?php if(!$asistencia->hora_entrada): ?> style="color: red;" <?php endif; ?>>
                                <?php echo e($asistencia->hora_entrada ? $asistencia->hora_entrada->format('Y/m/d H:i') : 'N/A'); ?>

                            </td>
                            <td <?php if(!$asistencia->hora_salida): ?> style="color: red;" <?php endif; ?>>
                                <?php echo e($asistencia->hora_salida ? $asistencia->hora_salida->format('Y/m/d H:i') : 'N/A'); ?>

                            </td>
                            <td <?php if($asistencia->retardo): ?> style="color: red;" <?php else: ?> style="color: green;" <?php endif; ?>>
                                <?php echo e($asistencia->retardo ? 'Sí' : 'No'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6">No se encontraron registros.</td></tr>
                    <?php endif; ?>
                <?php else: ?>
                    <tr><td colspan="6">No se encontraron registros.</td></tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="6" style="text-align: right; font-weight: bold; padding-right: 1rem;">Total de retardos: <?php echo e($totalRetardos); ?></td>
                </tr>
                <?php if(isset($horasFormateadas)): ?>
                    <tr>
                        <td colspan="6" style="text-align: right; font-weight: bold; padding-right: 1rem;">
                            <strong> Total de horas trabajadas:</strong> <?php echo e($horasFormateadas); ?> horas
                        </td>
                    </tr>
                <?php endif; ?>
            </tfoot>
        </table>
    </div>

    <footer class="footer">
        <div>&copy; Cumbres International School</div>
        <div>Documento generado automáticamente por el sistema.</div>
    </footer>
</body>

</html>
<?php /**PATH C:\Desarrollos-Alex\Dev-Cumbres\ChecadorCumbres\resources\views/admin/asistencias/reporte.blade.php ENDPATH**/ ?>