

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-semibold mb-4 text-gray-800">Crear nuevo usuario</h2>

    <?php if($errors->any()): ?>
    <div class="mb-4 bg-red-100 border border-red-400 text-red-700 p-3 rounded">
        <ul class="list-disc pl-4 text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form id="crear-user-form" method="POST" action="<?php echo e(route('admin.usuarios.guardar')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700">Nombres</label>
            <input type="text" name="name" required class="w-full mt-1 px-4 py-2 border rounded focus:ring focus:ring-blue-200">
        </div>

         <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700">Apellidos</label>
            <input type="text" name="last_name" required class="w-full mt-1 px-4 py-2 border rounded focus:ring focus:ring-blue-200">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700">Correo electrónico</label>
            <input type="email" name="email" id="email" required class="w-full mt-1 px-4 py-2 border rounded focus:ring focus:ring-blue-200">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700">Contraseña</label>
            <input type="password" name="password" required class="w-full mt-1 px-4 py-2 border rounded focus:ring focus:ring-blue-200">
        </div>

        <div class="mb-4">
            <label class="block text-sm font-semibold text-gray-700">Rol</label>
            <select name="level_user" class="w-full mt-1 px-4 py-2 border rounded focus:ring focus:ring-blue-200">
                <option value="0">Usuario</option>
                <option value="1">Administrador</option>
                <?php if(auth()->user()->level_user >1): ?>
                <option value="2">Super Administrador</option>
                <?php endif; ?>
            </select>
        </div>

        <div class="mb-4">
            <label class="inline-flex items-center">
                <input type="checkbox" name="yes_notifications" value="1" class="form-checkbox text-blue-600">
                <span class="ml-2 text-sm text-gray-700">Recibir notificaciones</span>
            </label>
        </div>

        <div class="flex justify-end">
            <a href="<?php echo e(route('admin.preferencias')); ?>" class="px-4 py-2 text-gray-600 hover:underline">Cancelar</a>
            <button type="submit" class="ml-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                Guardar
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Desarrollos-Alex\Dev-Cumbres\ChecadorCumbres\resources\views/admin/usuarios/crear.blade.php ENDPATH**/ ?>