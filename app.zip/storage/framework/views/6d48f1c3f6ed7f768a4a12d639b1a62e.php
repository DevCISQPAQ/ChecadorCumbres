

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-semibold text-gray-800 mb-6">Bienvenido(a), <?php echo e(Auth::user()->name); ?></h2>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Desarrollos-Alex\Dev-Cumbres\ChecadorCumbres\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>