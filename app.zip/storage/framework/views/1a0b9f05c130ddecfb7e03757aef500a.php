

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white p-6 rounded shadow">
    <h2 class="text-2xl font-semibold mb-4 text-gray-800">Editar horario</h2>

    <?php if($errors->any()): ?>
    <div class="mb-4 bg-red-100 border border-red-400 text-red-700 p-3 rounded">
        <ul class="list-disc pl-4 text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('admin.usuarios.data')); ?>">
        <?php echo csrf_field(); ?>


        <div class="mb-5">
            <label for="hora_limite_entrada" class="block text-xl font-medium text-gray-700">
                Hora límite de entrada
            </label>
            <p class=" text-xs text-gray-500">Este horario sera indicador de retardo.</p>
            <input type="time" name="hora_limite_entrada" id="hora_limite_entrada"
                value="<?php echo e(old('hora_limite_entrada', $config['hora_limite_entrada'] ?? '')); ?>"
                class="mt-2 py-3 text-xl block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
        </div>

        <?php if(auth()->user()->level_user >= 2): ?>
        <div class="mb-5">
            <label for="hora_limite_salida" class="block text-xl font-medium text-gray-700">
                Hora de marcado como salida
            </label>
            <p class=" text-xs text-gray-500">Se usa para establecer la hora en que el chequeo del empleado se marca como salida.</p>
            <input type="time" name="hora_limite_salida" id="hora_limite_salida"
                value="<?php echo e(old('hora_limite_salida', $config['hora_limite_salida'] ?? '')); ?>"
                class="mt-2 py-3 text-xl block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500">
        </div>
        <?php endif; ?>

        <div class="flex justify-end">
            <a href="<?php echo e(route('admin.preferencias')); ?>" class="px-4 py-2 text-gray-600 hover:underline">Cancelar</a>
            <button type="submit" class="ml-4 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded">
                Actualizar
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Desarrollos-Alex\Dev-Cumbres\ChecadorCumbres\resources\views/admin/usuarios/configurar.blade.php ENDPATH**/ ?>