<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('dias_festivos', function (Blueprint $table) {
            $table->id();

            $table->string('nombre');

            $table->date('fecha');

            $table->boolean('oficial')
                ->default(true);

            $table->timestamps();
            
            $table->unique('fecha');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('dias_festivos');
    }
};
