@php
$empleadoUnico = null;
$todosMismoEmpleado = true;

if(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Empleado) {
// Si es colección de empleados
$primerEmpleado = $asistencias[0] ?? null;
foreach ($asistencias as $empleado) {
if (is_null($empleadoUnico)) {
$empleadoUnico = $empleado;
} elseif ($empleadoUnico->id !== $empleado->id) {
$todosMismoEmpleado = false;
break;
}
}
} elseif(isset($asistencias[0]) && $asistencias[0] instanceof \App\Models\Asistencia) {
// Si es colección de asistencias
$primerEmpleado = $asistencias[0]->empleado ?? null;
foreach ($asistencias as $asistencia) {
if (is_null($empleadoUnico)) {
$empleadoUnico = $asistencia->empleado;
} elseif ($empleadoUnico->id !== $asistencia->empleado->id) {
$todosMismoEmpleado = false;
break;
}
}
} else {
$primerEmpleado = null;
}
@endphp

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="{{ public_path('css/pdf.css') }}" type="text/css">
    <title>Reporte de Asistencias</title>
</head>

<body>
    <table class="w-full">
        <tr>
            <td class="w-half">
                <img src="{{ public_path('img/escudo-gris.svg') }}" alt="Logo" style="width: .5rem;">
            </td>
            <td class="w-half">
                <h2>Cumbres International School</h2>
            </td>
        </tr>
    </table>

    <div class="margin-top">
        <table class="w-full">
            <tr>
                <td class="w-half">
                    <div>
                        <h4>Reporte de Asistencias</h4>
                    </div>
                    @if($todosMismoEmpleado && $empleadoUnico)
                    <p>De: {{ $empleadoUnico->nombres }} {{ $empleadoUnico->apellido_paterno }} {{ $empleadoUnico->apellido_materno }}</p>
                    @endif
                </td>
                <td class="w-half" style="text-align: right;">
                    Fecha: {{ now()->format('d/m/Y') }}
                </td>
            </tr>
        </table>
    </div>

    <div class="margin-top">
        <table class="products">
            <thead>
                <tr>
                    <th>N. Empleado</th>
                    <th>Nombre</th>
                    <th>Departamento</th>
                    <th>Fecha</th>
                    <th>Hora de entrada</th>
                    <th>Hora de salida</th>
                    <th>Retardo</th>
                </tr>
            </thead>
            <tbody>
                @php
                $totalRetardos = 0;
                @endphp

                @forelse($asistencias as $asistencia)
                @php
                $empleado = $asistencia->empleado;

                $finDeSemana = $asistencia->estado === 'libre'
                && !$asistencia->hora_entrada
                && !$asistencia->hora_salida
                && in_array(date('N', strtotime($asistencia->fecha)), [6, 7]);

                if ($asistencia->estado === 'retardo') {
                $totalRetardos++;
                }

                $colorEstado = match($asistencia->estado) {
                'presente' => 'green',
                'retardo' => '#ca8a04',
                'falta' => 'red',
                'vacaciones' => 'blue',
                'permiso' => 'purple',
                'libre' => '#0891b2',
                'incapacidad' => '#27F5D6',
                'festivo' => 'gray',
                default => '#6b7280',
                };

                $textoEstado = match($asistencia->estado) {
                'presente' => 'Presente',
                'retardo' => 'Retardo',
                'falta' => 'Falta',
                'vacaciones' => 'Vacaciones',
                'permiso' => 'Permiso',
                'incapacidad' => 'Incapacidad',
                'libre' => 'Libre',
                'festivo' => 'Festivo',
                default => 'Sin registro',
                };
                @endphp

                @endphp
                <tr class="items">
                    <td>{{ $asistencia->n_empleado ?? ($empleado->n_empleado ?? '-') }}</td>
                    <td>{{ $empleado ? $empleado->nombres . ' ' . $empleado->apellido_paterno . ' ' . $empleado->apellido_materno : 'N/A' }}</td>
                    <td>{{ $empleado->departamento->nombre ?? 'N/A' }}</td>
                    {{-- Columna de fecha --}}
                    <td>{{ $asistencia->created_at ? $asistencia->created_at->format('d/m/Y') : '-' }}</td>
                    {{-- Hora de entrada --}}
                    <td @if(!$asistencia->hora_entrada && $asistencia->estado !== 'libre') style="color: red;" @endif>
                        {{ $asistencia->estado === 'libre' ? ( $finDeSemana ? 'Fin de semana' : 'Libre' ) : ($asistencia->hora_entrada ? \Carbon\Carbon::parse($asistencia->hora_entrada)->format('H:i') : 'Sin registro') }}
                    </td>

                    {{-- Hora de salida --}}
                    <td @if(!$asistencia->hora_salida && $asistencia->estado !== 'libre') style="color: red;" @endif>
                        {{ $asistencia->estado === 'libre' ? ( $finDeSemana ? 'Fin de semana' : 'Libre' ) : ($asistencia->hora_salida ? \Carbon\Carbon::parse($asistencia->hora_salida)->format('H:i') : 'Sin registro') }}
                    </td>
                    
                    {{-- Estado --}}
                    <td style="color: {{ $colorEstado }}; font-weight: bold;">
                        {{ $textoEstado }}
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7">No se encontraron registros.</td>
                </tr>
                @endforelse
            </tbody>

            <tfoot>
                <tr>
                    <td colspan="7" style="text-align: right; font-weight: bold; padding-right: 1rem;">Total de retardos: {{ $totalRetardos }}</td>
                </tr>
                @if(isset($horasFormateadas))
                <tr>
                    <td colspan="7" style="text-align: right; font-weight: bold; padding-right: 1rem;">
                        <strong> Total de horas trabajadas:</strong> {{ $horasFormateadas }} horas
                    </td>
                </tr>
                @endif
            </tfoot>
        </table>
    </div>

    <footer class="footer">
        <div>&copy; Cumbres International School</div>
        <div>Documento generado automáticamente por el sistema.</div>
    </footer>
</body>

</html>