<?php $__env->startSection('content'); ?>
<!-- <div class="flex justify-between gap-4">
    <h2 class="md:text-xl text-xm font-semibold text-blue-800 mb-6 text-center">Bienvenido(a), <?php echo e(Auth::user()->name); ?></h2>
    <h2 class="md:text-xl text-xm font-semibold text-gray-800 mb-6 text-center"><?php echo e(\Carbon\Carbon::now()->locale('es')->isoFormat('dddd, D [de] MMMM [de] YYYY')); ?></h2>
</div> -->
<h2 class="text-2xl font-semibold text-gray-800 mb-6">Asistencias</h2>


<div class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-7 gap-2 md:gap-6 md:space-y-0 space-y-2">

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Asistencias</h3>
        <p class="text-xl mt-1 text-center font-bold text-green-600">
            <?php echo e($asistenciaE ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Retardos</h3>
        <p class="text-xl mt-1 text-center font-bold text-yellow-500">
            <?php echo e($retardosHoy ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Faltas</h3>
        <p class="text-xl mt-1 text-center font-bold text-red-600">
            <?php echo e($faltasHoy ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Vacaciones</h3>
        <p class="text-xl mt-1 text-center font-bold text-blue-600">
            <?php echo e($vacacionesHoy ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Permisos</h3>
        <p class="text-xl mt-1 text-center font-bold text-purple-600">
            <?php echo e($permisosHoy ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Incapacidad</h3>
        <p class="text-xl mt-1 text-center font-bold text-pink-600">
            <?php echo e($incapacidadHoy ?? 0); ?>

        </p>
    </div>

    <div class="bg-white p-2 rounded-lg shadow">
        <h3 class="text-sm text-center font-semibold text-gray-700">Libres</h3>
        <p class="text-xl mt-1 text-center font-bold text-gray-600">
            <?php echo e($libresHoy ?? 0); ?>

        </p>
    </div>

</div>


<div x-data="{
    buscar: '<?php echo e(request('buscar', '')); ?>',
    fecha_inicio: '<?php echo e(request('fecha_inicio', '')); ?>',
    fecha_fin: '<?php echo e(request('fecha_fin', '')); ?>',
    departamento: '<?php echo e(request('departamento', '')); ?>',
    retardo: '<?php echo e(request('retardo', '')); ?>',
    hora_entrada: '<?php echo e(request('hora_entrada', '')); ?>',
    estado: '<?php echo e(request('estado', '')); ?>',
    hora_salida: '<?php echo e(request('hora_salida', '')); ?>'}" class="pt-5">
    <!-- Formulario de filtros -->
    <form id="filtrosForm" method="GET" action="<?php echo e(route('admin.asistencias')); ?>"
        class="flex flex-col md:flex-row flex-wrap md:items-end md:gap-4 space-y-2 md:space-y-0">

        <div class="w-full md:w-auto">
            <label class="block mb-1 font-semibold text-sm">Buscar nombre o apellido</label>
            <input type="text" name="buscar" x-model="buscar" placeholder="Buscar..."
                class="border rounded px-3 py-1 w-full md:w-64 text-sm" />
        </div>

        <div class="w-full sm:w-1/2 md:w-auto">
            <label class="block mb-1 font-semibold text-sm">Fecha inicio</label>
            <input type="date" name="fecha_inicio" x-model="fecha_inicio"
                class="border rounded px-3 py-1 w-full text-sm" />
        </div>

        <div class="w-full sm:w-1/2 md:w-auto">
            <label class="block mb-1 font-semibold text-sm">Fecha fin</label>
            <input type="date" name="fecha_fin" x-model="fecha_fin"
                class="border rounded px-3 py-1 w-full text-sm" />
        </div>

        <!-- grupo de select filtrar -->
        <div class=" flex flex-col md:flex-row gap-4">
            <!-- 2 columnas SOLO en móvil -->
            <div class="w-full flex flex-row gap-2">
                <!-- Departamento -->
                <div class="w-1/2 md:w-32">
                    <label class="block mb-1 font-semibold text-sm">Departamento</label>
                    <select name="departamento"
                        x-model="departamento"
                        class="border rounded px-3 py-1 w-full text-sm">

                        <option value="">Todos</option>

                        <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($departamento->id); ?>"
                            <?php echo e(request('departamento') == $departamento->id ? 'selected' : ''); ?>>

                            <?php echo e($departamento->nombre); ?>


                        </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>
                </div>

                <div class="w-full md:w-32">
                    <label class="block mb-1 font-semibold text-sm">Estado</label>

                    <select name="estado" x-model="estado"
                        class="border rounded px-3 py-1 w-full text-sm">

                        <option value="">Todos</option>

                        <option value="presente">Presente</option>
                        <option value="retardo">Retardo</option>
                        <option value="falta">Falta</option>
                        <option value="vacaciones">Vacaciones</option>
                        <option value="permiso">Permiso</option>
                        <option value="incapacidad">Incapacidad</option>
                        <option value="libre">Libre</option>
                        <option value="festivo">Festivo</option>

                    </select>
                </div>

            </div>

            <!-- Hora entrada + salida (solo se agrupan en móviles) -->
            <div class="w-full flex flex-row gap-2 md:w-auto">
                <!-- Hora de entrada -->
                <div class="w-1/2 md:w-32">
                    <label class="block mb-1 font-semibold text-sm">Hora de entrada</label>
                    <select name="hora_entrada" x-model="hora_entrada" class="border rounded px-3 py-1 w-full text-sm">
                        <option value="">Todos</option>
                        <option value="1">Con hora</option>
                        <option value="0">Sin hora</option>
                    </select>
                </div>
                <!-- Hora de salida -->
                <div class="w-1/2 md:w-32">
                    <label class="block mb-1 font-semibold text-sm">Hora de salida</label>
                    <select name="hora_salida" x-model="hora_salida" class="border rounded px-3 py-1 w-full text-sm">
                        <option value="">Todos</option>
                        <option value="1">Con hora</option>
                        <option value="0">Sin hora</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Boton filtrar -->
        <div class="w-full sm:w-1/2 md:w-auto">
            <button type="submit" class="bg-blue-600 text-white px-4 py-1 rounded hover:bg-blue-700 w-full">
                Filtrar
            </button>
        </div>

        <?php
        $hayFiltros = collect(request()->only([
        'buscar',
        'fecha_inicio',
        'fecha_fin',
        'departamento',
        'estado',
        'hora_entrada',
        'hora_salida'
        ]))->filter()->isNotEmpty();
        ?>

        <?php if(request()->query()): ?>
        <div class="w-full sm:w-1/2 md:w-auto">
            <a href="<?php echo e(route('admin.asistencias')); ?>"
                class="block text-center px-4 py-1 bg-red-600 hover:bg-red-400 text-white rounded w-full">
                Borrar filtros
            </a>
        </div>
        <?php endif; ?>
    </form>

    <div class="flex justify-end gap-2 mb-1 pr-4 pt-5"">
        <form method=" GET" action="<?php echo e(route('admin.asistencias.reporte.pdf')); ?>" target="_blank">
        <!-- Envía los filtros actuales como inputs ocultos -->
        <input type="hidden" name="buscar" value="<?php echo e(request('buscar')); ?>">
        <input type="hidden" name="fecha_inicio" value="<?php echo e(request('fecha_inicio')); ?>">
        <input type="hidden" name="fecha_fin" value="<?php echo e(request('fecha_fin')); ?>">
        <input type="hidden" name="departamento" value="<?php echo e(request('departamento')); ?>">
        <input type="hidden" name="retardo" value="<?php echo e(request('retardo')); ?>">
        <input type="hidden" name="hora_entrada" value="<?php echo e(request('hora_entrada')); ?>">
        <input type="hidden" name="hora_salida" value="<?php echo e(request('hora_salida')); ?>">
        <input type="hidden" name="estado" value="<?php echo e(request('estado')); ?>">

        <button type="submit" class="bg-gray-600 text-white px-4 py-1 rounded hover:bg-blue-700">
            Crear reporte
        </button>
        </form>

        <form method="GET" action="<?php echo e(route('admin.asistencias.reporte.excel')); ?>">
            <!-- Envía los filtros actuales como inputs ocultos -->
            <input type="hidden" name="buscar" value="<?php echo e(request('buscar')); ?>">
            <input type="hidden" name="fecha_inicio" value="<?php echo e(request('fecha_inicio')); ?>">
            <input type="hidden" name="fecha_fin" value="<?php echo e(request('fecha_fin')); ?>">
            <input type="hidden" name="departamento" value="<?php echo e(request('departamento')); ?>">
            <input type="hidden" name="retardo" value="<?php echo e(request('retardo')); ?>">
            <input type="hidden" name="hora_entrada" value="<?php echo e(request('hora_entrada')); ?>">
            <input type="hidden" name="hora_salida" value="<?php echo e(request('hora_salida')); ?>">
            <input type="hidden" name="estado" value="<?php echo e(request('estado')); ?>">

            <button type="submit"
                class="bg-green-600 text-white px-4 py-1 rounded hover:bg-green-700">
                Exportar Excel
            </button>
        </form>
    </div>


    <!-- Tabla de asistencias -->
    <div class="overflow-x-auto">

        <div class="max-h-[500px] overflow-y-auto border border-gray-300 rounded-lg">

            <table class="min-w-full bg-white">

                <thead class="sticky top-0 bg-gray-700 text-white">

                    <tr class="text-xs">

                        <th class="p-2 text-center">N. Empleado</th>

                        <th class="p-2 text-center">Nombre</th>

                        <th class="p-2 text-center">Departamento</th>

                        <?php if($hayFiltros): ?>
                        <th class="p-2 text-center">Fecha</th>
                        <?php endif; ?>

                        <th class="p-2 text-center">Hora de entrada</th>

                        <th class="p-2 text-center">Hora de salida</th>

                        <th class="p-2 text-center">Estado</th>

                    </tr>

                </thead>

                <tbody class="text-xs">

                    <?php $__empty_1 = true; $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php

                    $empleado = $asistencia->empleado;

                    // Obtener checadas del día
                    $checadas = $asistencia->checadas->filter(function ($checada) use ($asistencia) {

                    return \Carbon\Carbon::parse($checada->fecha_hora)->toDateString()
                    === \Carbon\Carbon::parse($asistencia->fecha)->toDateString();

                    });

                    $entrada = $checadas
                    ->where('tipo', 'entrada')
                    ->first();

                    $salida = $checadas
                    ->where('tipo', 'salida')
                    ->last();

                    ?>

                    <tr class="border border-gray-300 hover:bg-gray-50">

                        <!-- NÚMERO EMPLEADO -->
                        <td class="p-3 text-center">

                            <?php echo e($empleado->n_empleado ?? 'N/A'); ?>


                        </td>

                        <!-- NOMBRE -->
                        <td class="p-3 text-center">

                            <?php echo e($empleado
                                ? $empleado->nombres . ' ' .
                                  $empleado->apellido_paterno . ' ' .
                                  $empleado->apellido_materno
                                : 'N/A'); ?>


                        </td>

                        <!-- DEPARTAMENTO -->
                        <td class="p-3 text-center">

                            <?php echo e($empleado->departamento->nombre ?? 'N/A'); ?>


                        </td>

                        <!-- FECHA -->
                        <?php if($hayFiltros): ?>

                        <td class="p-3 text-center">

                            <?php echo e(\Carbon\Carbon::parse($asistencia->fecha)->format('d/m/Y')); ?>


                        </td>

                        <?php endif; ?>

                        <!-- ENTRADA -->
                        <td class="p-3 text-center <?php echo e(!$entrada && $asistencia->estado !== 'libre' ? 'text-red-600 font-semibold' : ''); ?>">

                            <?php echo e($asistencia->estado === 'libre' && !$entrada && in_array(\Carbon\Carbon::parse($asistencia->fecha)->dayOfWeekIso, [6, 7]) ? 'Fin de semana'  : ($asistencia->estado === 'libre' && !$entrada ? 'Libre' : ($entrada ? \Carbon\Carbon::parse($entrada->fecha_hora)->format('H:i') : 'Sin registro'))); ?>


                        </td>

                        <!-- SALIDA -->
                        <td class="p-3 text-center <?php echo e(!$salida && $asistencia->estado !== 'libre' ? 'text-red-600 font-semibold' : ''); ?>">

                            <?php echo e($asistencia->estado === 'libre' && !$salida && in_array(\Carbon\Carbon::parse($asistencia->fecha)->dayOfWeekIso, [6, 7]) ? 'Fin de semana' : ($asistencia->estado === 'libre' && !$salida ? 'Libre' : ($salida ? \Carbon\Carbon::parse($salida->fecha_hora)->format('H:i') : 'Sin registro'))); ?>

                        </td>


                        <!-- ESTADO -->
                        <td class="p-3 text-center font-semibold

                            <?php switch($asistencia->estado):

                                case ('presente'): ?>
                                    text-green-600
                                <?php break; ?>

                                <?php case ('retardo'): ?>
                                    text-yellow-600
                                <?php break; ?>

                                <?php case ('falta'): ?>
                                    text-red-600
                                <?php break; ?>

                                <?php case ('vacaciones'): ?>
                                    text-blue-600
                                <?php break; ?>

                                <?php case ('permiso'): ?>
                                    text-purple-600
                                <?php break; ?>

                                <?php case ('incapacidad'): ?>
                                    text-red-700
                                <?php break; ?>

                                <?php case ('libre'): ?>
                                    text-cyan-600
                                <?php break; ?>

                                <?php case ('festivo'): ?>
                                    text-gray-600
                                <?php break; ?>

                                <?php case ('fin_semana'): ?>
                                text-orange-400
                                <?php break; ?>

                                <?php default: ?>
                                    text-gray-500

                            <?php endswitch; ?>
                        ">

                            <?php switch($asistencia->estado):

                            case ('presente'): ?>
                            Presente
                            <?php break; ?>

                            <?php case ('retardo'): ?>
                            Retardo
                            <?php break; ?>

                            <?php case ('falta'): ?>
                            Falta
                            <?php break; ?>

                            <?php case ('vacaciones'): ?>
                            Vacaciones
                            <?php break; ?>

                            <?php case ('permiso'): ?>
                            Permiso
                            <?php break; ?>

                            <?php case ('incapacidad'): ?>
                            Incapacidad
                            <?php break; ?>

                            <?php case ('festivo'): ?>
                            Festivo
                            <?php break; ?>

                            <?php case ('libre'): ?>
                            Libre
                            <?php break; ?>

                            <?php case ('fin_semana'): ?>
                            Fin de semana
                            <?php break; ?>

                            <?php default: ?>
                            Sin registro

                            <?php endswitch; ?>

                        </td>

                    </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="<?php echo e($hayFiltros ? 7 : 6); ?>"
                            class="text-center p-4">
                            No se encontraron registros.
                        </td>

                    </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

    <!-- Paginación -->
    <div class="mt-4">
        <?php echo e($asistencias->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Si hay query string y queremos ocultarla tras carga:
        if (window.location.search.length) {
            // opcional: conservas historial (replaceState) sin query
            window.history.replaceState({}, document.title, window.location.pathname);
        }
    });
</script>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/admin/asistencias/index.blade.php ENDPATH**/ ?>