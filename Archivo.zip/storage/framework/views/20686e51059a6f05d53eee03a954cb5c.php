<?php $__env->startSection('content'); ?>

<?php if($errors->any()): ?>
<div x-data="{ show: true }"
    x-init="setTimeout(() => show = false, 4000)"
    x-show="show"
    x-transition
    class="mb-5 bg-red-100 border border-red-400 text-red-700 p-4 rounded">
    <ul class="list-disc pl-5 text-sm">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">

    <!-- ===================================================== -->
    <!-- Permisos -->
    <!-- ===================================================== -->


    <div class="bg-white p-6 rounded-xl shadow">

        <div class="mb-3">
            <h1 class="text-2xl font-bold text-gray-800">
                Registrar permisos
            </h1>

            <p class="text-sm text-gray-500">
                Asigna un periodo de permisos a un empleado.
            </p>
        </div>

        <form id="guardar-vacaciones" action="<?php echo e(route('admin.vacaciones.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- EMPLEADO -->
            <div
                x-data="buscadorEmpleado(<?php echo e(Js::from($empleados)); ?>)"
                class="mb-4 relative">

                <label class="text-sm font-medium text-gray-700">
                    Asignar empleado
                </label>

                <!-- INPUT -->
                <input
                    type="text"
                    x-model="buscarEmpleado"
                    placeholder="Buscar empleado..."
                    class="w-full border px-3 py-1 mt-1 border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-cyan-400">

                <!-- RESULTADOS -->
                <template x-if="buscarEmpleado.length >= 2">

                    <div class="absolute z-50 w-full max-h-52 overflow-y-auto border bg-white border-gray-300 rounded-lg shadow">

                        <template
                            x-for="emp in empleadosFiltrados.slice(0,8)"
                            :key="emp.id">

                            <div
                                @click="seleccionarEmpleado(emp)"
                                class="p-3 hover:bg-gray-100 cursor-pointer border-b">

                                <div class="font-medium text-gray-800">

                                    <span x-text="emp.nombres"></span>

                                    <span x-text="emp.apellido_paterno"></span>

                                    <span x-text="emp.apellido_materno"></span>

                                </div>

                                <div class="text-xs text-gray-500">

                                    No. empleado:
                                    <span x-text="emp.n_empleado"></span>

                                </div>

                            </div>

                        </template>

                    </div>

                </template>

                <!-- EMPLEADO SELECCIONADO -->
                <div
                    x-show="empleadoSeleccionado"
                    class="mt-3 text-sm text-green-600">

                    Empleado seleccionado:

                    <span
                        class="font-semibold"
                        x-text="empleadoCompleto"></span>

                </div>

                <!-- INPUT HIDDEN -->
                <input
                    type="hidden"
                    name="empleado_id"
                    :value="empleadoSeleccionado?.id">

            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5">

                <!-- FECHA INICIO -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Fecha inicio
                    </label>

                    <input
                        type="date"
                        name="fecha_inicio"
                        value="<?php echo e(old('fecha_inicio')); ?>"
                        class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required>
                </div>

                <!-- FECHA FIN -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Fecha fin
                    </label>

                    <input
                        type="date"
                        name="fecha_fin"
                        value="<?php echo e(old('fecha_fin')); ?>"
                        class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required>
                </div>
            </div>
            <!-- MOTIVO -->
            <div class="mb-3">
                <label class="block text-sm font-medium text-gray-700 mb-2">
                    Observaciones / Motivo
                </label>

                <textarea
                    name="motivo"
                    rows="4"
                    class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Opcional..."><?php echo e(old('motivo')); ?></textarea>
            </div>

            <!-- BOTONES -->
            <div class="flex justify-end gap-3">
                <button
                    type="submit"
                    class="bg-blue-600 cursor-pointer hover:bg-blue-700 text-white px-5 py-2 rounded-lg">
                    Guardar vacaciones
                </button>
            </div>

        </form>

        <!-- TABLA VACACIONES -->

    </div>

    <!-- ===================================================== -->
    <!-- Subsidio de incapacidad -->
    <!-- ===================================================== -->
    <div class="bg-white p-6 rounded-xl shadow h-fit">
        <div class="mb-3">
            <h1 class="text-2xl font-bold text-gray-800">
               Registrar subsidio de incapacidad
            </h1>

            <p class="text-sm text-gray-500">
                Asigna un periodo de subsidio de incapacidad a un empleado.
            </p>
        </div>
    </div>


</div>






<div x-data="{ abierto: false, id: null, url: '', fecha_inicio: '', fecha_fin: '', motivo: '',
    abrir(datos) {
        this.id = datos.id;
        this.url = datos.url;
        this.fecha_inicio = datos.fecha_inicio;
        this.fecha_fin = datos.fecha_fin;
        this.motivo = datos.motivo || '';

        this.abierto = true;
    }
     }"
    @editar-vacacion.window="abrir($event.detail)">

    <div
        x-show="abierto"
        x-cloak
        x-transition
        class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 px-4">

        <div
            @click.outside="abierto = false"
            class="bg-white w-full max-w-lg rounded-xl shadow-xl p-6">

            <div class="flex justify-between items-center mb-5">

                <h2 class="text-xl font-bold text-gray-800">
                    Editar vacaciones
                </h2>

                <button
                    type="button"
                    @click="abierto = false"
                    class="cursor-pointer text-gray-500 hover:text-gray-700 text-xl">

                    &times;

                </button>

            </div>

            <form
                :action="url"
                method="POST">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

                    <div>

                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Fecha inicio
                        </label>

                        <input
                            type="date"
                            name="fecha_inicio"
                            x-model="fecha_inicio"
                            required
                            class="w-full border-gray-300 rounded-lg shadow-sm">

                    </div>

                    <div>

                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Fecha fin
                        </label>

                        <input
                            type="date"
                            name="fecha_fin"
                            x-model="fecha_fin"
                            required
                            class="w-full border-gray-300 rounded-lg shadow-sm">

                    </div>

                </div>

                <div class="mb-5">

                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Observaciones / Motivo
                    </label>

                    <textarea
                        name="motivo"
                        rows="4"
                        x-model="motivo"
                        class="w-full border-gray-300 rounded-lg shadow-sm"></textarea>

                </div>

                <div class="flex justify-end gap-3">

                    <button
                        type="button"
                        @click="abierto = false"
                        class="cursor-pointer bg-gray-100 hover:bg-gray-200 text-gray-700 px-5 py-2 rounded-lg">

                        Cancelar

                    </button>

                    <button
                        type="submit"
                        class="cursor-pointer bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg">

                        Guardar cambios

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/admin/incidencias/index.blade.php ENDPATH**/ ?>