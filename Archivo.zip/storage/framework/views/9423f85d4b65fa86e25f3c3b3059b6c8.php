<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <title>Reporte Individual de Asistencias</title>

    <style>
        @page {
            size: A4 portrait;
            margin: 25px 28px;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            font-size: 10px;
            color: #000;
            margin: 0;
            padding: 0;
            line-height: 1.3;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            font-size: 19px;
            margin: 0 0 4px 0;
        }

        h3 {
            color: #2c3e50;
            font-size: 11px;
            margin: 12px 0 7px 0;
        }

        p {
            margin: 5px 0;
            line-height: 1.3;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 9px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 6px 5px;
            color: #000;
        }

        th {
            background-color: #ecf0f1;
            color: #2c3e50;
            text-align: center;
            font-size: 9px;
        }

        td {
            text-align: center;
            font-size: 9px;
        }

        .encabezado,
        .encabezado td {
            border: none;
            padding: 0;
        }

        .encabezado {
            margin-bottom: 10px;
        }

        .subtitulo {
            font-size: 12px;
            text-align: center;
            margin: 0;
        }

        .datos th {
            width: 20%;
        }

        .datos td {
            width: 30%;
            font-size: 9px;
        }

        .detalle {
            table-layout: fixed;
        }

        .detalle th,
        .detalle td {
            padding: 7px 3px;
            font-size: 8px;
            vertical-align: middle;
        }

        .detalle th:nth-child(1) {
            width: 13%;
        }

        .detalle th:nth-child(2) {
            width: 11%;
        }

        .detalle th:nth-child(3) {
            width: 14%;
        }

        .detalle th:nth-child(4) {
            width: 14%;
        }

        .detalle th:nth-child(5) {
            width: 14%;
        }

        .detalle th:nth-child(6) {
            width: 17%;
        }

        .detalle th:nth-child(7) {
            width: 17%;
        }

        .resumen {
            margin-top: 4px;
        }

        .resumen th,
        .resumen td {
            padding: 6px;
            font-size: 9px;
        }

        .resumen th {
            text-align: left;
        }

        .observaciones {
            text-align: left;
            padding: 8px;
            line-height: 1.4;
        }

        .firma-container {
            margin-top: 25px;
            margin-bottom: 5px;
        }

        .firma {
            width: 45%;
            border: none;
            text-align: center;
            padding: 0 15px;
        }

        .linea-firma {
            border-top: 1px solid #000;
            padding-top: 8px;
        }

        .footer {
            font-size: 8px;
            color: #7f8c8d;
            text-align: center;
            margin-top: 5px;
            padding: 0;
            line-height: 1;
            page-break-before: avoid;
            page-break-after: avoid;
            page-break-inside: avoid;
        }

        .saludo {
            margin: 7px 0;
        }

        .texto-descripcion {
            margin: 5px 0 8px 0;
        }

        .seccion {
            page-break-inside: avoid;
        }

        .firma-container,
        .firma-container tr {
            page-break-inside: avoid;
        }
    </style>
</head>

<body>

    

    <table style="border: none; margin-bottom: 20px;">
        <tr>
            <td style="border: none; text-align: center;">
                <h2 style="font-size: 18px;">
                    Cumbres International School
                </h2>

                <p style="text-align: center; font-size: 13px;">
                    Reporte Individual de Asistencias
                </p>
            </td>
        </tr>
    </table>


    

    <h3>Datos del empleado</h3>

    <table>
        <tbody>

            <tr>
                <th>N. Empleado</th>
                <td><?php echo e($empleado->n_empleado); ?></td>

                <th>Departamento</th>
                <td><?php echo e($empleado->departamento->nombre ?? 'N/A'); ?></td>
            </tr>

            <tr>
                <th>Nombre</th>
                <td colspan="3">
                    <?php echo e($empleado->nombres); ?>

                    <?php echo e($empleado->apellido_paterno); ?>

                    <?php echo e($empleado->apellido_materno); ?>

                </td>
            </tr>

            <tr>
                <th>Periodo</th>
                <td>
                    <?php echo e($fechaInicio->format('d/m/Y')); ?>

                    al
                    <?php echo e($fechaFin->format('d/m/Y')); ?>

                </td>

                <th>Generado</th>
                <td><?php echo e(now()->format('d/m/Y H:i')); ?></td>
            </tr>

        </tbody>
    </table>


    <p>
        Hola, <?php echo e($empleado->nombres); ?>.
    </p>

    <p>
        Este documento contiene el registro de tus asistencias,
        entradas, salidas, retardos, faltas, permisos, vacaciones
        e incapacidades correspondientes al periodo indicado.
    </p>


    

    <h3>Detalle de asistencias</h3>

    <table>

        <thead>
            <tr>
                <th>Fecha</th>
                <th>Día</th>
                <th>Hora de entrada</th>
                <th>Hora de salida</th>
                <th>Estado</th>
                <th>Minutos de retardo</th>
                <!-- <th>Horas trabajadas</th> -->
            </tr>
        </thead>

        <tbody>

            <?php $__currentLoopData = $asistencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php

            $estado = strtolower(trim($registro['estado'] ?? ''));

            $colorEstado = match($estado) {
            'presente' => 'green',
            'retardo' => '#ca8a04',
            'falta', 'sin registro' => 'red',
            'vacaciones' => 'blue',
            'permiso' => 'purple',
            'incapacidad' => '#0891b2',
            'libre' => '#0891b2',
            'festivo' => 'gray',
            default => '#6b7280',
            };

            $textoEstado = match($estado) {
            'presente' => 'Presente',
            'retardo' => 'Retardo',
            'falta' => 'Falta',
            'vacaciones' => 'Vacaciones',
            'permiso' => 'Permiso',
            'incapacidad' => 'Incapacidad',
            'libre' => 'Libre',
            'festivo' => 'Festivo',
            'sin registro' => 'Sin registro',
            default => ucfirst($estado),
            };

            ?>

            <tr>

                <td>
                    <?php echo e($registro['fecha']->format('d/m/Y')); ?>

                </td>

                <td>
                    <?php echo e($registro['dia']); ?>

                </td>

                <td>
                    <?php echo e($registro['hora_entrada'] ?? 'Sin registro'); ?>

                </td>

                <td>
                    <?php echo e($registro['hora_salida'] ?? 'Sin registro'); ?>

                </td>

                <td style="color: <?php echo e($colorEstado); ?>; font-weight: bold;">
                    <?php echo e($textoEstado); ?>

                </td>

                <td>
                    <?php if($estado === 'retardo'): ?>
                    <?php echo e($registro['minutos_retardo']); ?> min
                    <?php else: ?>
                    -
                    <?php endif; ?>
                </td>

               

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>


    

    <?php

    $registrosValidos = $asistencias->where('tipo', 'registro');

    $totalPresentes = $registrosValidos
    ->where('estado', 'presente')
    ->count();

    $totalRetardos = $registrosValidos
    ->where('estado', 'retardo')
    ->count();

    $totalFaltas = $registrosValidos
    ->where('estado', 'falta')
    ->count();

    $totalPermisos = $registrosValidos
    ->where('estado', 'permiso')
    ->count();

    $totalVacaciones = $registrosValidos
    ->where('estado', 'vacaciones')
    ->count();

    $totalIncapacidades = $registrosValidos
    ->where('estado', 'incapacidad')
    ->count();

    $totalSinRegistro = $asistencias
    ->where('tipo', 'sin_registro')
    ->count();

    $totalLibres = $asistencias
    ->where('estado', 'libre')
    ->count();

    $totalFestivos = $asistencias
    ->where('estado', 'festivo')
    ->count();

    $totalMinutosRetardo = $registrosValidos
    ->where('estado', 'retardo')
    ->sum('minutos_retardo');

    $totalHorasTrabajadas = $registrosValidos
    ->sum('horas_trabajadas');

    ?>

    <h3>Resumen de asistencia</h3>

    <table class="resumen">

        <tbody>

            <tr>
                <th>Asistencias normales</th>
                <td><?php echo e($totalPresentes); ?></td>

                <th>Retardos</th>
                <td><?php echo e($totalRetardos); ?></td>
            </tr>

            <tr>
                <th>Faltas registradas</th>
                <td><?php echo e($totalFaltas); ?></td>

                <th>Días sin registro</th>
                <td><?php echo e($totalSinRegistro); ?></td>
            </tr>

            <tr>
                <th>Permisos</th>
                <td><?php echo e($totalPermisos); ?></td>

                <th>Vacaciones</th>
                <td><?php echo e($totalVacaciones); ?></td>
            </tr>

            <tr>
                <th>Incapacidades</th>
                <td><?php echo e($totalIncapacidades); ?></td>

                <th>Días libres</th>
                <td><?php echo e($totalLibres); ?></td>
            </tr>

            <tr>
                <th>Días festivos</th>
                <td><?php echo e($totalFestivos); ?></td>

                <th>Minutos de retardo</th>
                <td><?php echo e($totalMinutosRetardo); ?> min</td>
            </tr>

            <!-- <tr>
                <th>Total de horas trabajadas</th>
                <td colspan="3">
                    <?php echo e(number_format((float) $totalHorasTrabajadas, 2)); ?> horas
                </td>
            </tr> -->

        </tbody>

    </table>


    

    <h3>Observaciones</h3>

    <table>
        <tr>
            <td class="observaciones">
                <?php $__currentLoopData = $registrosValidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(!empty($registro['observaciones'])): ?>
                <strong>
                    <?php echo e($registro['fecha']->format('d/m/Y')); ?>:
                </strong>
                <?php echo e($registro['observaciones']); ?>

                <br>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
        </tr>
    </table>


    

    <h3>Acuse de recibido</h3>

    <p>
        Mediante mi firma hago constar que he recibido y revisado
        el presente reporte de asistencia correspondiente al periodo indicado.
        Mi firma acredita únicamente la recepción del documento y no implica
        necesariamente mi conformidad con todos los registros.
    </p>

    <table class="firma-container">

        <tr>

            <td class="firma">

                <div class="linea-firma">

                    <?php echo e($empleado->nombres); ?>

                    <?php echo e($empleado->apellido_paterno); ?>

                    <?php echo e($empleado->apellido_materno); ?>


                    <br>

                    <strong>Firma del empleado</strong>

                </div>

            </td>

            <td style="width: 10%; border: none;"></td>

            <td class="firma">

                <div class="linea-firma">

                    <strong>Nombre y firma</strong>

                    <br>

                    Recursos Humanos

                </div>

            </td>

        </tr>

    </table>


    

    <footer class="footer">

        <div>
            &copy; <?php echo e(date('Y')); ?> Cumbres International School.
            Todos los derechos reservados.
        </div>

        <div>
            Documento generado automáticamente por el sistema.
        </div>

    </footer>

</body>

</html><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/emails/reporte_asistencia_individual.blade.php ENDPATH**/ ?>