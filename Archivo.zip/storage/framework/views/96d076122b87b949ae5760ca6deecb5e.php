<div class="h-screen flex flex-col" x-data="{ sidebarOpen: false }" @click.away="sidebarOpen = false">
    
    <div class="p-6 font-bold text-dm text-[#5D7E8D] border-b border-gray-300 text-center">
        <div class="flex justify-center mb-3">
            <img src="/img/sello-cumbres.svg" alt="Logo" class="h-24">
        </div>
        Panel de Control de Asistencias
    </div>

    
    <div class="h-full flex flex-col">
        <nav class="mt-6 flex-1 overflow-y-auto">
            <a href="<?php echo e(url('/admin/dashboard')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->is('admin/dashboard') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Dashboard
            </a>
            <a href="<?php echo e(route('admin.asistencias')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->routeIs('admin.asistencias*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Asistencias
            </a>
            <?php if(auth()->user()->level_user): ?>
            <a href="<?php echo e(route('admin.empleados')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->routeIs('admin.empleados*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Empleados
            </a>
            <?php endif; ?>
            
            <?php if(auth()->user()->level_user >= 1): ?>
            <a href="<?php echo e(route('admin.ausencias.index')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->routeIs('admin.ausencias.index*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Ausencias
            </a>
            <a href="<?php echo e(route('admin.festivos.index')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->routeIs('admin.festivos.index*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Festivos
            </a>
            <a href="<?php echo e(route('admin.preferencias')); ?>"
                class="block py-2.5 px-4 <?php echo e(request()->routeIs('admin.preferencias*') ? 'bg-blue-100 text-blue-700' : 'text-gray-700'); ?> hover:bg-blue-50 transition-colors">
                Preferencias
            </a>
            <?php endif; ?>
        </nav>
    </div>
    
    <div class="p-4 text-sm text-gray-500 border-t border-gray-300">
        &copy; <?php echo e(date('Y')); ?> Panel Admin
    </div>
</div><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/components/admin-sidebar.blade.php ENDPATH**/ ?>