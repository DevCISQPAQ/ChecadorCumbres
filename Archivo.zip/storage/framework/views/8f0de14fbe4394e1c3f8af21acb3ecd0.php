<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">

    <title>Reporte Semanal de Retardos y Asistencias</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            margin: 20px;
            background-color: #fff;
            color: #000;
        }

        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        h3 {
            color: #2c3e50;
            margin-top: 25px;
            margin-bottom: 10px;
        }

        p {
            margin-top: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 25px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 7px;
            color: #000;
        }

        th {
            background-color: #ecf0f1;
            text-align: left;
            color: #2c3e50;
        }

        .center {
            text-align: center;
        }

        .total {
            font-weight: bold;
        }

        .footer {
            font-size: 10px;
            color: #7f8c8d;
            text-align: center;
            margin-top: 50px;
        }

        .sin-registro {
            color: #c0392b;
        }

        .retardo {
            color: #d35400;
        }
    </style>
</head>

<body>

    
    
    

    <h2>Reporte Semanal de Retardos y Asistencias</h2>

    <p>
        <strong>Periodo:</strong>
        <?php echo e($inicioSemana->format('d/m/Y')); ?>

        al
        <?php echo e($finSemana->format('d/m/Y')); ?>

    </p>

    <p>
        Hola,
    </p>

    <p>
        Este es el resumen semanal de retardos y faltas de asistencia
        correspondientes al periodo indicado.
    </p>


    
    
    

    <h3>Empleados con Retardos</h3>

    <?php if($retardos->isEmpty()): ?>

    <p style="font-style: italic; color: #666;">
        No hay empleados con retardos esta semana.
    </p>

    <?php else: ?>

    <table>

        <thead>
            <tr>
                <th>N. Empleado</th>
                <th>Empleado</th>
                <th>Fecha</th>
                <th>Minutos de retardo</th>
            </tr>
        </thead>

        <tbody>

            <?php $__currentLoopData = $retardos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistenciasEmpleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
            $empleado = $asistenciasEmpleado->first()->empleado;
            $totalMinutos = $asistenciasEmpleado->sum('minutos_retardo');
            ?>

            <?php $__currentLoopData = $asistenciasEmpleado->sortBy('fecha'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>

                <td>
                    <?php echo e($empleado->n_empleado); ?>

                </td>

                <td>
                    <?php echo e($empleado->nombres); ?>

                    <?php echo e($empleado->apellido_paterno); ?>

                    <?php echo e($empleado->apellido_materno); ?>

                </td>

                <td>
                    <?php echo e(\Carbon\Carbon::parse($asistencia->fecha)->format('d/m/Y')); ?>

                </td>

                <td class="center retardo">
                    <?php echo e($asistencia->minutos_retardo); ?> min
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            

            <tr>

                <td colspan="3" class="total" style="text-align: right;">
                    Total de minutos de retardo:
                </td>

                <td class="center total">
                    <?php echo e($totalMinutos); ?> min
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

    <?php endif; ?>


    
    
    

    <h3>Empleados con Faltas o Sin Registro de Asistencia</h3>

    <?php if($empleadosSinAsistencia->isEmpty()): ?>

    <p style="font-style: italic; color: #666;">
        No hay faltas ni empleados sin registro de asistencia
        esta semana.
    </p>

    <?php else: ?>

    <table>

        <thead>

            <tr>
                <th>N. Empleado</th>
                <th>Empleado</th>
                <th class="center">Faltas</th>
                <th>Fechas</th>
            </tr>

        </thead>

        <tbody>

            <?php $__currentLoopData = $empleadosSinAsistencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php

            $empleado = $registro['empleado'];

            $totalFaltas = count($registro['faltas']);

            ?>

            <tr>

                

                <td>
                    <?php echo e($empleado->n_empleado); ?>

                </td>


                

                <td>
                    <?php echo e($empleado->nombres); ?>

                    <?php echo e($empleado->apellido_paterno); ?>

                    <?php echo e($empleado->apellido_materno); ?>

                </td>


                

                <td class="center sin-registro"
                    style="font-weight: bold;">

                    <?php echo e($totalFaltas); ?>


                </td>


                

                <td>

                    <?php $__currentLoopData = $registro['faltas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $falta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php echo e(\Carbon\Carbon::parse($falta['fecha'])->format('d/m/Y')); ?>


                    <?php if(!$loop->last): ?>
                    ,
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>

    </table>

    <?php endif; ?>


    
    
    

    <h3>Resumen</h3>

    <table>

        <tbody>

            <tr>
                <th>Empleados con retardos</th>
                <td class="center">
                    <?php echo e($retardos->count()); ?>

                </td>
            </tr>

            <tr>
                <th>Total de retardos</th>
                <td class="center">
                    <?php echo e($retardos->flatten()->count()); ?>

                </td>
            </tr>

            <tr>
                <th>Total de minutos de retardo</th>
                <td class="center">
                    <?php echo e($retardos->flatten()->sum('minutos_retardo')); ?> min
                </td>
            </tr>

            <tr>
                <th>Empleados con faltas</th>
                <td class="center">
                    <?php echo e($empleadosSinAsistencia->count()); ?>

                </td>
            </tr>

            <tr>
                <th>Total de faltas / días sin asistencia</th>
                <td class="center">
                    <?php echo e($empleadosSinAsistencia->sum(fn ($registro) => count($registro['faltas']))); ?>

                </td>
            </tr>

        </tbody>

    </table>


    
    
    

    <p>
        Por favor toma las medidas correspondientes.
    </p>

    <p style="font-size: 10px; color: #999;">
        Este es un documento generado automáticamente.
        No responda a este mensaje.
    </p>

    <div class="footer">
        &copy; <?php echo e(date('Y')); ?> Cumbres Querétaro.
        Todos los derechos reservados.
    </div>

</body>

</html><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/emails/reporte_pdf.blade.php ENDPATH**/ ?>