 
<?php $__env->startSection('content'); ?>
<?php
$roles = [
0 => 'Usuario',
1 => 'Administrador',
2 => 'Súper Administrador',
];
?>
<div class="px-6 py-3 bg-white rounded shadow mb-4">
    <h2 class="text-xl font-bold mb-3">Configuraciones</h2>
    <div class="flex gap-5">
        <a href="<?php echo e(route('admin.configuraciones')); ?>" class="bg-orange-500 text-white px-2 py-1 rounded hover:bg-orange-700">
            Departamentos / Horarios</a>
    </div>
</div>

<div class="p-6 bg-white rounded shadow">
    <div class="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 gap-2 sm:gap-0">
        <h2 class="text-xl font-bold">Usuarios</h2>
        <div class="flex  gap-2 sm:gap-3.5">
            <a href="<?php echo e(route('admin.usuarios.crear')); ?>" class="bg-blue-600 text-white px-2 py-1 rounded hover:bg-blue-700">Crear Usuario</a>
        </div>
    </div>

    <div class="overflow-x-auto">
        <div class="max-h-[500px] overflow-y-auto border border-gray-300 rounded-lg">
            <table class="w-full table-auto">
                <thead>
                    <tr class="bg-gray-200 text-left text-sm">
                        <th class="px-4 text-center py-2">Nombre</th>
                        <th class="px-4 text-center py-2">Correo</th>
                        <th class="px-4 text-center py-2">Rol</th>
                        <th class="px-4 text-center py-2">Notificaciones</th>
                        <th class="px-4 text-center py-2">Acciones</th>
                    </tr>
                </thead>
                <tbody class="text-sm">
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(auth()->user()->level_user < 2 && $usuario->level_user == 2): ?>
                        <?php continue; ?>
                        <?php endif; ?>
                        <tr class="border-b">
                            <td class="px-4 text-center py-2"><?php echo e($usuario->name); ?></td>
                            <td class="px-4 text-center py-2 max-w-[200px] truncate"><?php echo e($usuario->email); ?></td>
                            <td class="px-4 text-center py-2"><?php echo e($roles[$usuario->level_user] ?? 'Desconocido'); ?></td>
                            <td class="px-4 text-center py-2">
                                <?php echo e($usuario->yes_notifications ? 'Sí' : 'No'); ?>

                            </td>
                            <td class="px-4 py-2 space-x-2">
                                <a href="<?php echo e(route('admin.usuarios.editar', $usuario->id)); ?>" class="text-blue-600 hover:underline">Editar</a>
                                <form action="<?php echo e(route('admin.usuarios.eliminar', $usuario->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600 hover:underline"
                                        onclick="return confirm('¿Seguro que quieres eliminar este usuario?')">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/admin/usuarios/index.blade.php ENDPATH**/ ?>