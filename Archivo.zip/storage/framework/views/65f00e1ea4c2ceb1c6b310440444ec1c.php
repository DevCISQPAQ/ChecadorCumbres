<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(public_path('css/pdf.css')); ?>">
    <title>Reporte de ausencias</title>
</head>

<body>

    <table class="w-full">
        <tr>
            <td class="w-half">
                <img src="<?php echo e(public_path('img/escudo-gris.svg')); ?>"
                    style="width: .5rem;">
            </td>
            <td class="w-half">
                <h2>Cumbres International School</h2>
            </td>
        </tr>
    </table>

    <?php
    $totalDias = 0;

    foreach ($ausencias as $ausencia) {
    $inicio = \Carbon\Carbon::parse($ausencia->fecha_inicio);
    $fin = \Carbon\Carbon::parse($ausencia->fecha_fin);

    $totalDias += $inicio->diffInDays($fin) + 1;
    }
    ?>

    <div class="margin-top">

        <table class="w-full">
            <tr>
                <td>
                    <h4>Reporte de Ausencias</h4>

                    <p>
                        Empleado:
                        <strong>
                            <?php echo e($empleado->nombres); ?>

                            <?php echo e($empleado->apellido_paterno); ?>

                            <?php echo e($empleado->apellido_materno); ?>

                        </strong>
                    </p>

                    <p>
                        No. empleado:
                        <?php echo e($empleado->n_empleado); ?>

                    </p>
                </td>

                <td style="text-align:right">
                    Fecha:
                    <?php echo e(now()->format('d/m/Y')); ?>

                </td>
            </tr>
        </table>

    </div>

    <table class="products">

        <thead>
            <tr>
                <th>Tipo</th>
                <th>Inicio</th>
                <th>Fin</th>
                <th>Días</th>
                <th>Estado</th>
                <th>Motivo</th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $ausencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ausencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <?php
            $inicio = \Carbon\Carbon::parse($ausencia->fecha_inicio);
            $fin = \Carbon\Carbon::parse($ausencia->fecha_fin);

            $dias = $inicio->diffInDays($fin) + 1;

            if ($fin->lt(now()->startOfDay())) {
            $estado = 'Finalizada';
            } elseif (
            $inicio->lte(now()->startOfDay()) &&
            $fin->gte(now()->startOfDay())
            ) {
            $estado = 'En curso';
            } else {
            $estado = 'Próxima';
            }

            $tipos = [
            'vacaciones' => 'Vacaciones',
            'permiso' => 'Permiso',
            'incapacidad' => 'Incapacidad',
            ];

            $tipo = $tipos[$ausencia->tipo] ?? ucfirst($ausencia->tipo);
            ?>

            <tr class="items">

                <td><?php echo e($tipo); ?></td>

                <td>
                    <?php echo e($inicio->format('d/m/Y')); ?>

                </td>

                <td>
                    <?php echo e($fin->format('d/m/Y')); ?>

                </td>

                <td><?php echo e($dias); ?></td>

                <td><?php echo e($estado); ?></td>

                <td>
                    <?php echo e($ausencia->motivo ?: '-'); ?>

                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="6">
                    No tiene ausencias registradas.
                </td>
            </tr>

            <?php endif; ?>

        </tbody>

        <tfoot>
            <tr>
                <td colspan="6"
                    style="text-align:right;font-weight:bold;padding-right:1rem;">
                    Total días de ausencia: <?php echo e($totalDias); ?> días
                </td>
            </tr>
        </tfoot>

    </table>

    <footer class="footer">
        <div>
            © Cumbres International School
        </div>

        <div>
            Documento generado automáticamente por el sistema.
        </div>
    </footer>

</body>

</html><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/admin/ausencias/pdf-empleado.blade.php ENDPATH**/ ?>