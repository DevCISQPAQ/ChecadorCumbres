<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Reporte Semanal de Retardos y Asistencias</title>
</head>

<body style="font-family: Arial, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px;">

    <table width="100%" cellpadding="0" cellspacing="0"
        style="max-width: 700px; margin: auto; background-color: #ffffff; border-radius: 6px;">

        
        
        

        <tr>
            <td style="background-color: #2c3e50; color: #ffffff; padding: 20px; text-align: center;">

                <h2 style="margin: 0;">
                    📋 Reporte Semanal de Retardos y Asistencias
                </h2>

            </td>
        </tr>


        
        
        

        <tr>

            <td style="padding: 20px;">

                <p>Hola,</p>

                <p>
                    Este es el resumen semanal de retardos y faltas de asistencia.
                </p>

                

                <?php if(isset($inicioSemana) && isset($finSemana)): ?>

                <p style="color: #555;">

                    <strong>Periodo:</strong>

                    <?php echo e($inicioSemana->format('d/m/Y')); ?>


                    al

                    <?php echo e($finSemana->format('d/m/Y')); ?>


                </p>

                <?php endif; ?>


                
                
                

                <h3 style="color: #2c3e50; margin-top: 25px;">
                    ⏰ Empleados con Retardos
                </h3>


                <?php if($retardos->isEmpty()): ?>

                <p style="font-style: italic; color: #666;">
                    No hay empleados con retardos esta semana.
                </p>

                <?php else: ?>

                <table width="100%" cellpadding="0" cellspacing="0"
                    style="border-collapse: collapse; margin-bottom: 30px;">

                    <thead>

                        <tr>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                N. Empleado
                            </th>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Empleado
                            </th>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Fecha
                            </th>

                            <th align="center"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Retardo
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php $__currentLoopData = $retardos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistenciasEmpleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                        $empleado = $asistenciasEmpleado->first()->empleado;

                        $totalMinutos = $asistenciasEmpleado->sum('minutos_retardo');

                        ?>


                        <?php $__currentLoopData = $asistenciasEmpleado->sortBy('fecha'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asistencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>

                            <td style="padding: 8px; border-bottom: 1px solid #eee;">
                                <?php echo e($empleado->n_empleado); ?>

                            </td>


                            <td style="padding: 8px; border-bottom: 1px solid #eee;">

                                <?php echo e($empleado->nombres); ?>

                                <?php echo e($empleado->apellido_paterno); ?>


                            </td>


                            <td style="padding: 8px; border-bottom: 1px solid #eee;">

                                <?php echo e(\Carbon\Carbon::parse($asistencia->fecha)->format('d/m/Y')); ?>


                            </td>


                            <td align="center"
                                style="padding: 8px; border-bottom: 1px solid #eee; color: #d35400;">

                                <?php echo e($asistencia->minutos_retardo); ?> min

                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        

                        <tr>

                            <td colspan="3"
                                align="right"
                                style="padding: 8px; background-color: #fafafa; font-weight: bold;">

                                Total de minutos:

                            </td>

                            <td align="center"
                                style="padding: 8px; background-color: #fafafa; font-weight: bold;">

                                <?php echo e($totalMinutos); ?> min

                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

                <?php endif; ?>


                
                
                

                <h3 style="color: #2c3e50; margin-top: 25px;">
                    ⚠️ Empleados con Faltas o Sin Registro
                </h3>


                <?php if($empleadosSinAsistencia->isEmpty()): ?>

                <p style="font-style: italic; color: #666;">
                    No hay faltas ni empleados sin registro de asistencia esta semana.
                </p>

                <?php else: ?>

                <table width="100%" cellpadding="0" cellspacing="0"
                    style="border-collapse: collapse; margin-bottom: 30px;">

                    <thead>

                        <tr>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                N. Empleado
                            </th>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Empleado
                            </th>

                            <th align="center"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Faltas
                            </th>

                            <th align="left"
                                style="padding: 8px; border-bottom: 2px solid #ddd; background-color: #ecf0f1;">
                                Fechas
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php $__currentLoopData = $empleadosSinAsistencia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php

                        $empleado = $registro['empleado'];

                        $totalFaltas = count($registro['faltas']);

                        ?>


                        <tr>

                            

                            <td style="padding: 8px; border-bottom: 1px solid #eee;">
                                <?php echo e($empleado->n_empleado); ?>

                            </td>


                            

                            <td style="padding: 8px; border-bottom: 1px solid #eee;">

                                <?php echo e($empleado->nombres); ?>

                                <?php echo e($empleado->apellido_paterno); ?>


                            </td>


                            

                            <td align="center"
                                style="padding: 8px;
                       border-bottom: 1px solid #eee;
                       color: #c0392b;
                       font-weight: bold;">

                                <?php echo e($totalFaltas); ?>


                            </td>


                            

                            <td style="padding: 8px; border-bottom: 1px solid #eee;">

                                <?php $__currentLoopData = $registro['faltas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $falta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php echo e(\Carbon\Carbon::parse($falta['fecha'])->format('d/m/Y')); ?>


                                <?php if(!$loop->last): ?>
                                ,
                                <?php endif; ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </td>

                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

                <?php endif; ?>


                
                
                

                <h3 style="color: #2c3e50; margin-top: 25px;">
                    📊 Resumen
                </h3>


                <table width="100%" cellpadding="0" cellspacing="0"
                    style="border-collapse: collapse; margin-bottom: 25px;">

                    <tr>

                        <td style="padding: 8px; border-bottom: 1px solid #eee;">
                            Empleados con retardos
                        </td>

                        <td align="right"
                            style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">

                            <?php echo e($retardos->count()); ?>


                        </td>

                    </tr>


                    <tr>

                        <td style="padding: 8px; border-bottom: 1px solid #eee;">
                            Total de retardos
                        </td>

                        <td align="right"
                            style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">

                            <?php echo e($retardos->flatten()->count()); ?>


                        </td>

                    </tr>


                    <tr>

                        <td style="padding: 8px; border-bottom: 1px solid #eee;">
                            Total de minutos de retardo
                        </td>

                        <td align="right"
                            style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">

                            <?php echo e($retardos->flatten()->sum('minutos_retardo')); ?> min

                        </td>

                    </tr>


                    <tr>

                        <td style="padding: 8px; border-bottom: 1px solid #eee;">
                            Empleados con faltas
                        </td>

                        <td align="right"
                            style="padding: 8px; border-bottom: 1px solid #eee; font-weight: bold;">

                            <?php echo e($empleadosSinAsistencia->count()); ?>


                        </td>

                    </tr>


                    <tr>

                        <td style="padding: 8px;">
                            Total de faltas / días sin asistencia
                        </td>

                        <td align="right"
                            style="padding: 8px; font-weight: bold;">

                            <?php echo e($empleadosSinAsistencia->sum(fn ($registro) => count($registro['faltas']))); ?>


                        </td>

                    </tr>

                </table>


                
                
                

                <p style="margin-top: 20px;">
                    Por favor toma las medidas correspondientes.
                </p>

                <p style="color: #999; font-size: 12px;">
                    Este es un correo automático. No respondas a este mensaje.
                </p>

            </td>

        </tr>


        
        
        

        <tr>

            <td style="background-color: #ecf0f1;
                       color: #7f8c8d;
                       text-align: center;
                       padding: 10px;
                       border-bottom-left-radius: 6px;
                       border-bottom-right-radius: 6px;
                       font-size: 12px;">

                &copy; <?php echo e(date('Y')); ?>

                Cumbres Querétaro.
                Todos los derechos reservados.

            </td>

        </tr>

    </table>

</body>

</html><?php /**PATH /Users/lap-alexis/Documents/GitHub/ChecadorCumbres/resources/views/emails/reporte_retardos.blade.php ENDPATH**/ ?>